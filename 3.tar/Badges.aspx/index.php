<?php
header("Location: https://www.voidrev.us/info/roblox-badges");
?>