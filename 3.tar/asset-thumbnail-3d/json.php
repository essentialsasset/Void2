<?php header("Content-Type: application/json");
$assetId = (int)$_GET['assetId'];
?>
{"Url":"https://www.voidrev.us/asset-thumbnail-3d/?assetId=<?=$assetId;?>","Final":true}