<?php header("Content-Type: application/json");
$assetId = $_GET['assetId'];
$assetid = $_GET['assetid'];
if(isset($_GET['assetid'])){
echo '{"Url":"https://tr.rbxcdn.com/647b2019b78d7eca3fd92ec9e7809328/768/432/Image/Png","Final":true}';
}
if(isset($_GET['assetId'])){
echo '{"Url":"https://tr.rbxcdn.com/647b2019b78d7eca3fd92ec9e7809328/768/432/Image/Png","Final":true}';
}
//die(file_get_contents($_SERVER["DOCUMENT_ROOT"] . '/Thumbs/assetunknown.png'));
?>










